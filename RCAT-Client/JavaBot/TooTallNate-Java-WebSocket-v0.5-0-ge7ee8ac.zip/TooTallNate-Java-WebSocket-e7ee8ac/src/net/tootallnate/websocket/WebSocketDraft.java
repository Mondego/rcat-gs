package net.tootallnate.websocket;

/**
 * Enum for WebSocket Draft
 */
public enum WebSocketDraft {
  AUTO,
  DRAFT75,
  DRAFT76
}
